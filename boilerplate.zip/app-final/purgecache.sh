rm -rf build
rm -rf lib/bs/
rm -rf src/*.bs.js
rm -rf src/*/*.bs.js
